export const custom = [
  {
    name: 'neko',
    file: 'neko.png',
    keywords: ['neko', 'cat', 'cat butt', 'butt'],
  },
]
