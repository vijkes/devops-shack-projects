# Non Goals

* Turning n.eko into a service that serves multiple rooms and browsers/desktops.
  * For multiple room management software, visit https://github.com/m1k1o/neko-rooms.
* Supporting multiple platforms.
* Voice chat, use [Discord](https://discordapp.com/) or [Jitsi](https://meet.jit.si/).
