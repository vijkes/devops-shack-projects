# Mobile support

N.eko is now working on iOS and Android! Also, the UI screens have been fixed for small screens.

![mobile-screens](_media/mobile-support.png)
