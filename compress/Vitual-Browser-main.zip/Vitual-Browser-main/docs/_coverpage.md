<!-- _coverpage.md -->

<img src="_media/logo.png" width="450" height="auto"/>

> A self hosted virtual browser that runs in docker

[GitHub](https://github.com/m1k1o/neko/)
[Get Started](#neko)

<!-- background color -->

![color](#e2e2e2)
